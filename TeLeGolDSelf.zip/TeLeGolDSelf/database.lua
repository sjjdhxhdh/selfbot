do local _ = {
  hash = {
    files = {},
    gifs = {},
    stickers = {},
    typing = {},
    values = {
      mohamad = "jon"
    }
  }
}
return _
end